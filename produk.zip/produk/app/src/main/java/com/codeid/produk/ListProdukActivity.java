package com.codeid.produk;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class ListProdukActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ProdukAdapter adapter;
    ArrayList<Produk> produkList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_produk);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ProdukAdapter(this, produkList);
        recyclerView.setAdapter(adapter);

        fetchProdukData();
    }

    private void fetchProdukData() {
        new Thread(() -> {
            try {
                URL url = new URL("http://10.0.2.2/produk_api/get_produk.php"); // Ganti IP sesuai server
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }

                reader.close();

                JSONArray jsonArray = new JSONArray(sb.toString());
                produkList.clear();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);

                    Produk p = new Produk();
                    p.nama_produk = obj.getString("nama_produk");
                    p.deskripsi = obj.getString("deskripsi");
                    p.gambar_url = obj.getString("gambar_url");

                    produkList.add(p);
                }

                runOnUiThread(() -> adapter.notifyDataSetChanged());

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() ->
                        Toast.makeText(ListProdukActivity.this, "Gagal ambil data", Toast.LENGTH_SHORT).show()
                );
            }
        }).start();
    }
}
