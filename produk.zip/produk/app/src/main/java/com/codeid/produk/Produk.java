package com.codeid.produk;

public class Produk {
    public String nama_produk;
    public String deskripsi;
    public String gambar_url;

    public Produk() {
    }

    public Produk(String nama_produk, String deskripsi, String gambar_url) {
        this.nama_produk = nama_produk;
        this.deskripsi = deskripsi;
        this.gambar_url = gambar_url;
    }

    // Optional: tambahkan getter dan setter jika dibutuhkan
}
