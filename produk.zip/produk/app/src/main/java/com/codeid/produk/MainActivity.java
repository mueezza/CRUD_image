package com.codeid.produk;
import android.content.Intent;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import android.database.Cursor;


public class MainActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private Uri imageUri;

    private EditText namaProdukEditText, deskripsiEditText;
    private ImageView imageView;
    private Button pilihGambarBtn, kirimDataBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button btnLihatProduk = findViewById(R.id.btnLihatProduk);
        btnLihatProduk.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListProdukActivity.class);
            startActivity(intent);
        });


        namaProdukEditText = findViewById(R.id.namaProduk);
        deskripsiEditText = findViewById(R.id.deskripsi);
        imageView = findViewById(R.id.imageView);
        pilihGambarBtn = findViewById(R.id.pilihGambar);
        kirimDataBtn = findViewById(R.id.kirimData);

        pilihGambarBtn.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Pilih Gambar"), PICK_IMAGE_REQUEST);
        });

        kirimDataBtn.setOnClickListener(v -> {
            if (imageUri != null && !namaProdukEditText.getText().toString().isEmpty()) {
                new Thread(() -> uploadData()).start();
            } else {
                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this, "Isi semua data dan pilih gambar", Toast.LENGTH_SHORT).show()
                );
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            imageView.setImageURI(imageUri);
        }
    }

    private void uploadData() {
        try {
            String namaProduk = namaProdukEditText.getText().toString();
            String deskripsi = deskripsiEditText.getText().toString();

            String boundary = "===" + System.currentTimeMillis() + "===";
            String lineEnd = "\r\n";
            String twoHyphens = "--";

            URL url = new URL("http://10.0.2.2/produk_api/upload_produk.php"); // Ganti dengan IP server
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Connection", "Keep-Alive");
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

            DataOutputStream dos = new DataOutputStream(conn.getOutputStream());

            // Tambahkan field nama_produk
            dos.writeBytes(twoHyphens + boundary + lineEnd);
            dos.writeBytes("Content-Disposition: form-data; name=\"nama_produk\"" + lineEnd + lineEnd);
            dos.writeBytes(namaProduk + lineEnd);

            // Tambahkan field deskripsi
            dos.writeBytes(twoHyphens + boundary + lineEnd);
            dos.writeBytes("Content-Disposition: form-data; name=\"deskripsi\"" + lineEnd + lineEnd);
            dos.writeBytes(deskripsi + lineEnd);

            // Ambil nama file gambar
            String fileName = getFileName(imageUri);
            InputStream inputStream = getContentResolver().openInputStream(imageUri);

            // Tambahkan field gambar
            dos.writeBytes(twoHyphens + boundary + lineEnd);
            dos.writeBytes("Content-Disposition: form-data; name=\"gambar\"; filename=\"" + fileName + "\"" + lineEnd);
            dos.writeBytes("Content-Type: image/jpeg" + lineEnd + lineEnd);

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
            }

            dos.writeBytes(lineEnd);
            dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
            inputStream.close();
            dos.flush();
            dos.close();

            // Cek response
            int responseCode = conn.getResponseCode();
            InputStream responseStream = (responseCode == 200) ?
                    conn.getInputStream() : conn.getErrorStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(responseStream));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            runOnUiThread(() ->
                    Toast.makeText(MainActivity.this, "Response: " + response.toString(), Toast.LENGTH_LONG).show()
            );

        } catch (Exception e) {
            e.printStackTrace();
            runOnUiThread(() ->
                    Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show()
            );
        }
    }

    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx != -1) result = cursor.getString(idx);
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1) result = result.substring(cut + 1);
            }
        }
        return result;
    }
}
