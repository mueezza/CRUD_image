package com.codeid.produk;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ProdukAdapter extends RecyclerView.Adapter<ProdukAdapter.ViewHolder> {

    private List<Produk> produkList;
    private Context context;

    public ProdukAdapter(Context ctx, List<Produk> list) {
        this.context = ctx;
        this.produkList = list;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtNama, txtDeskripsi;
        ImageView imgProduk;

        public ViewHolder(View itemView) {
            super(itemView);
            txtNama = itemView.findViewById(R.id.txtNama);
            txtDeskripsi = itemView.findViewById(R.id.txtDeskripsi);
            imgProduk = itemView.findViewById(R.id.imgProduk);
        }
    }

    @Override
    public ProdukAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_produk, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ProdukAdapter.ViewHolder holder, int position) {
        Produk p = produkList.get(position);
        holder.txtNama.setText(p.nama_produk);
        holder.txtDeskripsi.setText(p.deskripsi);
        Picasso.get().load(p.gambar_url).into(holder.imgProduk);
    }

    @Override
    public int getItemCount() {
        return produkList.size();
    }
}
