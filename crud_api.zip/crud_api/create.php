<?php
include 'config.php';
//string jeneng ="arya";
$name  = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];


$sql = "INSERT INTO users (name, email, phone) VALUES ('$name', '$email', '$phone')";

if (mysqli_query($conn, $sql)) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error"]);
}
?>
