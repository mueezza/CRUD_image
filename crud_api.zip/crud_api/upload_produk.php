<?php
include 'config.php'; // Pastikan file ini mengatur $conn

$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["gambar"]["name"]);

if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
    $nama_produk = $_POST['nama_produk'];
    $deskripsi = $_POST['deskripsi'];
    $gambar = basename($_FILES["gambar"]["name"]);

    $sql = "INSERT INTO produk (nama_produk, deskripsi, gambar) VALUES ('$nama_produk', '$deskripsi', '$gambar')";
    if (mysqli_query($conn, $sql)) {
        echo json_encode([
            "status" => "success",
            "gambar_url" => "http://10.0.2.2/crud_api/uploads/" . $gambar // sesuaikan IP
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Gagal simpan ke database"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Gagal upload file"]);
}
?>
