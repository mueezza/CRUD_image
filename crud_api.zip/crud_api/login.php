<?php
header('Content-Type: application/json');
include 'config.php';

$email    = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Validasi awal
if (empty($email) || empty($password)) {
    echo json_encode(["status" => "failed", "message" => "Email dan password wajib diisi"]);
    exit;
}

// Query user
$sql = "SELECT * FROM users WHERE email = '$email' AND password = MD5('$password')";
$result = mysqli_query($conn, $sql);

if ($row = mysqli_fetch_assoc($result)) {
    echo json_encode([
        "status" => "success",
        "message" => "Login berhasil",
        "data" => [
            "id" => $row['id'],
            "name" => $row['name'],
            "email" => $row['email']
        ]
    ]);
} else {
    echo json_encode([
        "status" => "failed",
        "message" => "Email atau password salah"
    ]);
}
?>
